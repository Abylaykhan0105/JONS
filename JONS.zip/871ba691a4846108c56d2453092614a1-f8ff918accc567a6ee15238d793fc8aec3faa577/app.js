let app = document.documentElement; // the whole document object
let container = document.getElementById("res");

// onload function that is fired when the document loads
const onload = () => {
  getData();
};

// fucntion to get remote data in (backend integration)
const getData = () => {
  fetch("https://jsonplaceholder.typicode.com/users")
    .then(res => res.json())
    .then(datas => {
      datas.map(data => {
        console.log(data);
        createCard(data.name, data.username);
      });
    });
};

const createCard = (title, content) => {
  let card = document.createElement("div", { class: "card" });
  let cardTitle = document.createElement("h3");
  let cardContent = document.createElement("p");
  // setting up class name for elements
  card.setAttribute("class","card");
  // adding values
  cardTitle.innerText = title;
  cardContent.innerText = content;
  // appending created elements to the parent element
  card.appendChild(cardTitle);
  card.appendChild(cardContent);
  container.appendChild(card);
};